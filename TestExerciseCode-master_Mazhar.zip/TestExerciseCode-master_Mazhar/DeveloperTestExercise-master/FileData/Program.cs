﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {

            List<string> versionList = new List<string>{ "-v", "--v", "/v", "--version" };
            List<string> sizeList = new List<string> { "-s", "--s", "/s", "--size" };

            if (args.Length == 0)
            {
                Console.WriteLine("Please provide Functionality to perform and File Name");
                return;
            }

            if (args.Length == 1)
            {
                Console.WriteLine("Functionality to perform or File Name is missing.");
                return;
            }

            if (args.Length == 2)
            {
                FileDetails fileDetails = new FileDetails();

                if (versionList.Contains(args[0].ToString()))
                {
                    Console.WriteLine("{0}", fileDetails.Version(args[1].ToString()));
                }
                else
                {
                    Console.WriteLine("{0}", fileDetails.Size(args[1].ToString()));
                }

            }            

        }
    }
}
